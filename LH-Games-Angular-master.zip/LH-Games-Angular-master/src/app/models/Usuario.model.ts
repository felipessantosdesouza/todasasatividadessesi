export class Usuario{
    public login?: string;
    public senha?: string;
}